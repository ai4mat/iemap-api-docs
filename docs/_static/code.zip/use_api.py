# Import everything from iemap_api
from iemap_api import *

# define user credentials for API requests
# in jupyter notebook use
# import getpass
# pwd=getpass.getpass()
# api = IEMAP('user@enea.it',pwd)


# use  `pip install pipreqs` within this directory
# to generate necessary requirements

user = "sergio.ferlito@enea.it"
pwd = "ai4mat"
api = IEMAP(user, pwd)

# api.download_file("6b39ac4704eb5e36707766fc92e442b029d80ba8.dat")

api.login()


# api.delete_project_file("edac628c0fb38f05da49778f8ebf38941e94835e")
# Show current project id
# api.get_id()
# exit(0)

# show user saved projects
# api.my_projects()

# grab a valid project id from previous printed list and set one
api.set_id("637cad819478f40cf454017e")


api.save(
    metadata="./metadata_example.json", list_proj_files=["../migration/CIFs/1.cif"]
)


# add project file to a previously save project
# api.save_project_files(
#     project_files=[
#         # "../migration/CIFs/1.cif"
#         "../migration/CIFs/10.cif"
#     ],
#     show_debug_info=True,
# )
api.save_project_files(project_files=["../migration/CIFs/10.cif"], show_debug_info=True)

# not necessary but useful to get token and view it
# api.get_token()
# api.show_token()

# method save allow to save metadata and, eventually, project files in one single step
# metadata argument is a valid path for a json file (need to have a valid schema)
# or a python dictionary
# api.save(metadata="./1.json")

# define a list of valid files path
# proj_files = ["../migration/CIFs/0.cif", "../migration/CIFs/8.cif"]

# save project and file
# api.save(metadata="./metadata_example.json", list_proj_files=proj_files)

# query a specific document by ID
# id = "636fd222d0e4198716b18d36"
# api.query(id)
# api.get_id()
# additional files can be saved at later time using
additional_files_proj = [
    "../migration/BANDs/0_bandsdown.dat",
    "../migration/BANDs/0_bandsup.dat",
    "../migration/BANDs/1_bandsdown.dat",
    "../migration/QE/10.in",
    "../migration/QE/10.out",
    "../migration/CIFs/10.cif",
]

# save additional project files to current ID
# api.save_project_files(project_files=additional_files_proj, show_debug_info=True)


api.save_project_files(project_files=["../migration/CIFs/10.cif"], show_debug_info=True)

# api.save_property_files({"numeric_pro": "./0.dat"})
